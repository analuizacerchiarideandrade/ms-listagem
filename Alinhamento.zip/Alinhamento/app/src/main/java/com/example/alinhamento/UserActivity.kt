package com.example.alinhamento

class UserActivity {
}