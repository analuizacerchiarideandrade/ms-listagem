package com.example.alinhamento;

public class ConteudoTextos {
}
